import json
import os
from dataclasses import dataclass, asdict
from typing import Optional, Dict, Any

@dataclass
class VideoEffectConfig:
    main_scale: int = 80
    corner_radius: int = 0
    border_width: int = 0
    border_color: tuple = (255, 255, 255)
    opacity: int = 0
    blur: int = 45
    bg_scale: int = 120
    brightness: int = 0
    saturation: int = 100
    hue: int = 0
    effect: str = "无"

class ConfigManager:
    def __init__(self, config_dir: str = "configs"):
        self.config_dir = config_dir
        self._ensure_config_dir()
        self.current_config: VideoEffectConfig = VideoEffectConfig()

    def _ensure_config_dir(self):
        """确保配置目录存在"""
        if not os.path.exists(self.config_dir):
            os.makedirs(self.config_dir)

    def save_config(self, name: str) -> bool:
        """保存当前配置"""
        try:
            config_path = os.path.join(self.config_dir, f"{name}.json")
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(asdict(self.current_config), f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"保存配置失败: {str(e)}")
            return False

    def load_config(self, name: str) -> bool:
        """加载配置"""
        try:
            config_path = os.path.join(self.config_dir, f"{name}.json")
            with open(config_path, 'r', encoding='utf-8') as f:
                config_dict = json.load(f)
                self.current_config = VideoEffectConfig(**config_dict)
            return True
        except Exception as e:
            print(f"加载配置失败: {str(e)}")
            return False

    def list_configs(self) -> list:
        """列出所有可用的配置"""
        configs = []
        for file in os.listdir(self.config_dir):
            if file.endswith('.json'):
                configs.append(file[:-5])  # 移除 .json 后缀
        return configs

    def update_config(self, **kwargs) -> None:
        """更新当前配置"""
        for key, value in kwargs.items():
            if hasattr(self.current_config, key):
                setattr(self.current_config, key, value)

    def get_config(self) -> Dict[str, Any]:
        """获取当前配置"""
        return asdict(self.current_config)

    def reset_config(self) -> None:
        """重置为默认配置"""
        self.current_config = VideoEffectConfig()

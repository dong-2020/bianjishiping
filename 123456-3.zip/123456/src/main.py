import sys
import cv2
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout
from PyQt6.QtWidgets import QPushButton, QFileDialog, QLabel, QColorDialog
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QImage, QPixmap

from .video_processor import VideoProcessor
from .ui_controls import VideoControls

class VideoBlurApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("视频模糊背景效果增强版 2.0")
        self.setGeometry(100, 100, 1280, 900)
        
        # 初始化组件
        self.video_processor = VideoProcessor()
        self.controls = VideoControls()
        self.video_path = None
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)
        
        self._init_ui()
        self._connect_signals()
        
    def _init_ui(self):
        """初始化UI"""
        # 创建主窗口部件
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout(self.central_widget)
        
        # 创建视频显示标签
        self.video_label = QLabel()
        self.video_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.video_label.setStyleSheet("background-color: black;")
        self.layout.addWidget(self.video_label)
        
        # 创建控制面板
        self.layout.addLayout(self.controls.create_control_panel())
        
        # 创建按钮
        button_layout = QHBoxLayout()
        
        self.select_button = QPushButton("选择视频")
        self.select_button.clicked.connect(self.select_video)
        button_layout.addWidget(self.select_button)
        
        self.process_button = QPushButton("开始处理")
        self.process_button.clicked.connect(self.process_video)
        self.process_button.setEnabled(False)
        button_layout.addWidget(self.process_button)
        
        self.save_button = QPushButton("保存视频")
        self.save_button.clicked.connect(self.save_video)
        self.save_button.setEnabled(False)
        button_layout.addWidget(self.save_button)
        
        self.layout.addLayout(button_layout)
        
    def _connect_signals(self):
        """连接信号"""
        # 连接边框颜色按钮
        self.controls.border_color_button.clicked.connect(self.choose_border_color)
        
        # 连接音频控制信号
        self.controls.volume_slider.valueChanged.connect(self._update_volume)
        self.controls.mute_checkbox.stateChanged.connect(self._update_mute)
        
    def _update_volume(self, value):
        """更新音量"""
        # 将滑块值（0-200）转换为音频倍数（0.0-2.0）
        volume = value / 100.0
        self.video_processor.set_audio_volume(volume)
        
        # 更新音量显示标签
        if self.controls.mute_checkbox.isChecked():
            self.controls.volume_value_label.setText("静音")
        else:
            self.controls.volume_value_label.setText(f"{value}%")
            
        # 更新音量图标
        if value == 0 or self.controls.mute_checkbox.isChecked():
            self.controls.volume_label.setText("🔇")
        elif value < 50:
            self.controls.volume_label.setText("🔈")
        elif value < 100:
            self.controls.volume_label.setText("🔉")
        else:
            self.controls.volume_label.setText("🔊")
        
    def _update_mute(self, state):
        """更新静音状态"""
        mute = state == Qt.CheckState.Checked.value
        self.video_processor.set_audio_mute(mute)
        
        # 更新音量显示
        if mute:
            self.controls.volume_value_label.setText("静音")
            self.controls.volume_label.setText("🔇")
        else:
            value = self.controls.volume_slider.value()
            self.controls.volume_value_label.setText(f"{value}%")
            # 根据音量值更新图标
            if value == 0:
                self.controls.volume_label.setText("🔇")
            elif value < 50:
                self.controls.volume_label.setText("🔈")
            elif value < 100:
                self.controls.volume_label.setText("🔉")
            else:
                self.controls.volume_label.setText("🔊")
        
    def display_frame(self, frame):
        """显示视频帧"""
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_frame.shape
        bytes_per_line = ch * w
        
        qt_image = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
        scaled_pixmap = QPixmap.fromImage(qt_image).scaled(
            self.video_label.size(),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
        self.video_label.setPixmap(scaled_pixmap)

    def select_video(self):
        """选择视频文件"""
        file_name, _ = QFileDialog.getOpenFileName(
            self,
            "选择视频文件",
            "",
            "Video Files (*.mp4 *.avi *.mkv);;All Files (*)"
        )
        if file_name:
            self.video_path = file_name
            self.process_button.setEnabled(True)
            self.save_button.setEnabled(True)
            self.video_processor.open_video(self.video_path)
            ret, frame = self.video_processor.read_frame()
            if ret:
                self.display_frame(frame)
    
    def save_video(self):
        """保存处理后的视频"""
        if not self.video_path:
            return
            
        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "保存视频",
            "",
            "MP4 Files (*.mp4);;AVI Files (*.avi)"
        )
        
        if output_path:
            params = self.controls.get_parameters()
            # 使用新的process_video方法来处理和保存视频
            self.video_processor.process_video(self.video_path, output_path, params)
    
    def process_video(self):
        """处理视频"""
        if not self.timer.isActive():
            self.video_processor.open_video(self.video_path)
            self.timer.start(33)  # 约30fps
            self.process_button.setText("停止")
        else:
            self.timer.stop()
            self.video_processor.close_video()
            self.process_button.setText("开始处理")
            
    def update_frame(self):
        """更新视频帧"""
        ret, frame = self.video_processor.read_frame()
        if ret:
            params = self.controls.get_parameters()
            processed = self.video_processor.process_frame(frame, params)
            self.display_frame(processed)
        else:
            self.timer.stop()
            self.video_processor.close_video()
            self.process_button.setText("开始处理")
            
    def choose_border_color(self):
        """选择边框颜色"""
        color = QColorDialog.getColor(self.controls.border_color, self)
        if color.isValid():
            self.controls.border_color = color
            
    def closeEvent(self, event):
        """关闭事件处理"""
        self.video_processor.close_video()
        event.accept()

def main():
    app = QApplication(sys.argv)
    window = VideoBlurApp()
    window.show()
    sys.exit(app.exec())

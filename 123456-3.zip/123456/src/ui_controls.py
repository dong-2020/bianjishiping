from PyQt6.QtWidgets import (QVBoxLayout, QHBoxLayout, QPushButton, QLabel, 
                           QSlider, QGroupBox, QComboBox, QColorDialog, QCheckBox)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor

class VideoControls:
    def __init__(self):
        self.border_color = QColor(255, 255, 255)  # 默认白色边框
        self._create_sliders()
        
    def _create_sliders(self):
        """初始化所有滑块控件"""
        # 主视频控制
        self.main_scale_slider = None
        self.corner_slider = None
        self.border_slider = None
        self.opacity_slider = None
        
        # 音频控制
        self.volume_slider = None
        self.mute_checkbox = None
        self.volume_value_label = None
        
        # 背景控制
        self.blur_slider = None
        self.bg_scale_slider = None
        self.brightness_slider = None
        self.saturation_slider = None
        self.hue_slider = None
        self.effect_combo = None
        self.border_color_button = None

    def update_border_slider(self, max_width):
        """更新边框宽度滑块的最大值"""
        if self.border_slider:
            current_value = min(self.border_slider.value(), max_width)
            self.border_slider.setMaximum(max_width)
            self.border_slider.setValue(current_value)
            self.border_slider.setToolTip(f"边框宽度 (0-{max_width}像素)")

    def reset_controls(self):
        """重置所有控件到默认值"""
        if self.main_scale_slider:
            self.main_scale_slider.setValue(80)
        if self.corner_slider:
            self.corner_slider.setValue(0)
        if self.border_slider:
            self.border_slider.setValue(0)
        if self.opacity_slider:
            self.opacity_slider.setValue(0)
        if self.volume_slider:
            self.volume_slider.setValue(100)
        if self.mute_checkbox:
            self.mute_checkbox.setChecked(False)
        if self.blur_slider:
            self.blur_slider.setValue(45)
        if self.bg_scale_slider:
            self.bg_scale_slider.setValue(120)
        if self.brightness_slider:
            self.brightness_slider.setValue(0)
        if self.saturation_slider:
            self.saturation_slider.setValue(100)
        if self.hue_slider:
            self.hue_slider.setValue(0)
        if self.effect_combo:
            self.effect_combo.setCurrentText("无")
        self.border_color = QColor(255, 255, 255)

    def create_control_panel(self):
        """创建控制面板"""
        control_layout = QHBoxLayout()
        control_layout.addWidget(self._create_main_controls())
        control_layout.addWidget(self._create_background_controls())
        return control_layout
        
    def _create_main_controls(self):
        """创建主视频控制组"""
        main_group = QGroupBox("主视频控制")
        main_layout = QVBoxLayout()
        
        # 主视频缩放控制
        main_scale_label = QLabel("主视频缩放 (60-90%)")
        self.main_scale_slider = QSlider(Qt.Orientation.Horizontal)
        self.main_scale_slider.setMinimum(60)
        self.main_scale_slider.setMaximum(90)
        self.main_scale_slider.setValue(80)
        main_layout.addWidget(main_scale_label)
        main_layout.addWidget(self.main_scale_slider)
        
        # 音频控制
        audio_group = QGroupBox("音频控制")
        audio_layout = QVBoxLayout()
        
        # 音量控制水平布局
        volume_layout = QHBoxLayout()
        
        # 音量图标和标签
        volume_label = QLabel("🔊")  # 使用音量图标
        volume_layout.addWidget(volume_label)
        
        # 音量滑块
        self.volume_slider = QSlider(Qt.Orientation.Horizontal)
        self.volume_slider.setMinimum(0)
        self.volume_slider.setMaximum(200)
        self.volume_slider.setValue(100)
        self.volume_slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.volume_slider.setTickInterval(50)  # 每50显示一个刻度
        self.volume_slider.setToolTip("调整音量 (100%为原始音量)")
        volume_layout.addWidget(self.volume_slider)
        
        # 音量数值显示
        self.volume_value_label = QLabel("100%")
        self.volume_value_label.setMinimumWidth(50)  # 确保标签有足够的宽度
        volume_layout.addWidget(self.volume_value_label)
        
        audio_layout.addLayout(volume_layout)
        
        # 静音复选框水平布局
        mute_layout = QHBoxLayout()
        self.mute_checkbox = QCheckBox("静音")
        mute_layout.addWidget(self.mute_checkbox)
        mute_layout.addStretch()  # 添加弹性空间
        
        audio_layout.addLayout(mute_layout)
        audio_group.setLayout(audio_layout)
        main_layout.addWidget(audio_group)
        
        # 圆角控制
        corner_label = QLabel("圆角半径 (0-50)")
        self.corner_slider = QSlider(Qt.Orientation.Horizontal)
        self.corner_slider.setMinimum(0)
        self.corner_slider.setMaximum(50)
        self.corner_slider.setValue(0)
        main_layout.addWidget(corner_label)
        main_layout.addWidget(self.corner_slider)
        
        # 边框宽度
        border_label = QLabel("边框宽度")
        self.border_slider = QSlider(Qt.Orientation.Horizontal)
        self.border_slider.setMinimum(0)
        self.border_slider.setMaximum(1)  # 初始设置为1，等待视频加载后更新
        self.border_slider.setValue(0)
        self.border_slider.setToolTip("请先加载视频")
        main_layout.addWidget(border_label)
        main_layout.addWidget(self.border_slider)
        
        # 边框颜色选择
        self.border_color_button = QPushButton("选择边框颜色")
        main_layout.addWidget(self.border_color_button)
        
        # 透明度控制
        opacity_label = QLabel("透明度 (0-50%)")
        self.opacity_slider = QSlider(Qt.Orientation.Horizontal)
        self.opacity_slider.setMinimum(0)
        self.opacity_slider.setMaximum(50)
        self.opacity_slider.setValue(0)
        main_layout.addWidget(opacity_label)
        main_layout.addWidget(self.opacity_slider)
        
        main_group.setLayout(main_layout)
        return main_group
        
    def _create_background_controls(self):
        """创建背景控制组"""
        bg_group = QGroupBox("背景控制")
        bg_layout = QVBoxLayout()
        
        # 背景模糊控制
        blur_label = QLabel("模糊程度")
        self.blur_slider = QSlider(Qt.Orientation.Horizontal)
        self.blur_slider.setMinimum(1)
        self.blur_slider.setMaximum(99)
        self.blur_slider.setValue(45)
        bg_layout.addWidget(blur_label)
        bg_layout.addWidget(self.blur_slider)
        
        # 背景放大控制
        bg_scale_label = QLabel("背景放大 (110-150%)")
        self.bg_scale_slider = QSlider(Qt.Orientation.Horizontal)
        self.bg_scale_slider.setMinimum(110)
        self.bg_scale_slider.setMaximum(150)
        self.bg_scale_slider.setValue(120)
        bg_layout.addWidget(bg_scale_label)
        bg_layout.addWidget(self.bg_scale_slider)
        
        # 背景亮度控制
        brightness_label = QLabel("背景亮度 (-50 to 50)")
        self.brightness_slider = QSlider(Qt.Orientation.Horizontal)
        self.brightness_slider.setMinimum(-50)
        self.brightness_slider.setMaximum(50)
        self.brightness_slider.setValue(0)
        bg_layout.addWidget(brightness_label)
        bg_layout.addWidget(self.brightness_slider)
        
        # 背景饱和度控制
        saturation_label = QLabel("背景饱和度 (0-200%)")
        self.saturation_slider = QSlider(Qt.Orientation.Horizontal)
        self.saturation_slider.setMinimum(0)
        self.saturation_slider.setMaximum(200)
        self.saturation_slider.setValue(100)
        bg_layout.addWidget(saturation_label)
        bg_layout.addWidget(self.saturation_slider)
        
        # 背景色调控制
        hue_label = QLabel("背景色调 (-180 to 180)")
        self.hue_slider = QSlider(Qt.Orientation.Horizontal)
        self.hue_slider.setMinimum(-180)
        self.hue_slider.setMaximum(180)
        self.hue_slider.setValue(0)
        bg_layout.addWidget(hue_label)
        bg_layout.addWidget(self.hue_slider)
        
        # 背景效果选择
        effect_label = QLabel("背景特效")
        self.effect_combo = QComboBox()
        self.effect_combo.addItems(["无", "镜像", "左右渐变", "上下渐变"])
        bg_layout.addWidget(effect_label)
        bg_layout.addWidget(self.effect_combo)
        
        bg_group.setLayout(bg_layout)
        return bg_group
        
    def get_parameters(self):
        """获取所有控制参数"""
        return {
            'main_scale': self.main_scale_slider.value(),
            'corner_radius': self.corner_slider.value(),
            'border_width': self.border_slider.value(),
            'border_color': (
                self.border_color.blue(),
                self.border_color.green(),
                self.border_color.red()
            ),
            'opacity': self.opacity_slider.value(),
            'blur': self.blur_slider.value(),
            'bg_scale': self.bg_scale_slider.value(),
            'brightness': self.brightness_slider.value(),
            'saturation': self.saturation_slider.value(),
            'hue': self.hue_slider.value(),
            'effect': self.effect_combo.currentText(),
            'volume': self.volume_slider.value() / 100.0,  # 转换为0-2.0范围
            'mute': self.mute_checkbox.isChecked()
        }

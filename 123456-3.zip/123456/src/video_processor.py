import cv2
import numpy as np
from moviepy.editor import VideoFileClip
import tempfile
import os

class VideoProcessor:
    def __init__(self):
        """初始化视频处理器"""
        self.cap = None
        self.out = None
        self.video_width = 0
        self.video_height = 0
        self.temp_dir = tempfile.gettempdir()
        self.audio_params = {
            'volume': 1.0,
            'mute': False
        }
        self.current_video_path = None

    def open_video(self, video_path):
        """打开视频文件"""
        if self.cap is not None:
            self.close_video()
        
        self.current_video_path = video_path
        self.cap = cv2.VideoCapture(video_path)
        if self.cap.isOpened():
            self.video_width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            self.video_height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            return True
        return False

    def close_video(self):
        """关闭视频"""
        if self.cap is not None:
            self.cap.release()
            self.cap = None
        if self.out is not None:
            self.out.release()
            self.out = None
        self.video_width = 0
        self.video_height = 0
        self.current_video_path = None

    def set_audio_volume(self, volume):
        """设置音频音量"""
        self.audio_params['volume'] = max(0.0, min(2.0, volume))
        print(f"设置音量为: {self.audio_params['volume']}")

    def set_audio_mute(self, mute):
        """设置是否静音"""
        self.audio_params['mute'] = mute
        print(f"设置静音为: {mute}")

    def read_frame(self):
        """读取一帧视频"""
        if self.cap is not None:
            return self.cap.read()
        return False, None

    def get_max_border_width(self):
        """获取当前视频允许的最大边框宽度"""
        if self.video_width == 0 or self.video_height == 0:
            return 0
        # 限制边框最大宽度为视频短边的 1/8
        return min(self.video_width, self.video_height) // 8

    @staticmethod
    def apply_corner_radius(image, radius):
        """应用圆角效果"""
        if radius <= 0:
            return image
            
        h, w = image.shape[:2]
        mask = np.zeros((h, w), np.uint8)
        
        cv2.rectangle(mask, (radius, radius), (w-radius, h-radius), 255, -1)
        cv2.circle(mask, (radius, radius), radius, 255, -1)
        cv2.circle(mask, (w-radius, radius), radius, 255, -1)
        cv2.circle(mask, (radius, h-radius), radius, 255, -1)
        cv2.circle(mask, (w-radius, h-radius), radius, 255, -1)
        
        mask = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
        mask = mask.astype(float) / 255
        return (image.astype(float) * mask).astype(np.uint8)

    @staticmethod
    def apply_border(image, width, color):
        """应用边框效果"""
        if width <= 0:
            return image
            
        h, w = image.shape[:2]
        
        # 创建一个与原图大小相同的画布
        result = image.copy()
        
        # 计算边框的内边界，确保不会超出图像范围
        border_width = min(width, min(h, w) // 4)
        
        # 使用cv2.rectangle绘制实心边框
        cv2.rectangle(result, (0, 0), (w, h), color, border_width)
        
        return result

    @staticmethod
    def apply_background_effect(image, effect):
        """应用背景特效"""
        if effect == "镜像":
            return cv2.flip(image, 1)
        elif effect == "左右渐变":
            h, w = image.shape[:2]
            gradient = np.linspace(0.7, 1.3, w)
            gradient = np.tile(gradient, (h, 1))
            gradient = np.dstack([gradient] * 3)
            return cv2.multiply(image.astype(float), gradient).astype(np.uint8)
        elif effect == "上下渐变":
            h, w = image.shape[:2]
            gradient = np.linspace(0.7, 1.3, h)
            gradient = np.tile(gradient.reshape(-1, 1), (1, w))
            gradient = np.dstack([gradient] * 3)
            return cv2.multiply(image.astype(float), gradient).astype(np.uint8)
        return image

    @staticmethod
    def adjust_hue(image, hue):
        """调整色调"""
        if hue == 0:
            return image
            
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV).astype(np.float32)
        h, s, v = cv2.split(hsv)
        h = (h + hue) % 180
        hsv = cv2.merge([h, s, v])
        return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)

    @staticmethod
    def adjust_brightness_contrast(img, brightness=0):
        """调整亮度对比度"""
        if brightness != 0:
            if brightness > 0:
                shadow = brightness
                highlight = 255
            else:
                shadow = 0
                highlight = 255 + brightness
            alpha_b = (highlight - shadow)/255
            gamma_b = shadow
            
            buf = cv2.addWeighted(img, alpha_b, img, 0, gamma_b)
        else:
            buf = img.copy()
        return buf

    @staticmethod
    def adjust_saturation(img, saturation):
        """调整饱和度"""
        img_hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype("float32")
        (h, s, v) = cv2.split(img_hsv)
        s = s * (saturation/100)
        s = np.clip(s, 0, 255)
        img_hsv = cv2.merge([h, s, v])
        return cv2.cvtColor(img_hsv.astype("uint8"), cv2.COLOR_HSV2BGR)

    def process_frame(self, frame, params):
        """处理单帧视频"""
        try:
            height, width = frame.shape[:2]
            
            # 创建背景
            scale_factor = params['bg_scale'] / 100
            bg_width = int(width * scale_factor)
            bg_height = int(height * scale_factor)
            background = cv2.resize(frame, (bg_width, bg_height))
            
            # 应用模糊
            blur_value = params['blur']
            if blur_value % 2 == 0:
                blur_value += 1
            background = cv2.GaussianBlur(background, (blur_value, blur_value), 0)
            
            # 应用背景效果
            background = self.adjust_brightness_contrast(background, params['brightness'])
            background = self.adjust_saturation(background, params['saturation'])
            background = self.adjust_hue(background, params['hue'])
            background = self.apply_background_effect(background, params['effect'])
            
            # 裁剪背景
            x_offset = (bg_width - width) // 2
            y_offset = (bg_height - height) // 2
            background = background[y_offset:y_offset+height, x_offset:x_offset+width]
            
            # 处理主视频
            main_scale = params['main_scale'] / 100
            main_width = int(width * main_scale)
            main_height = int(height * main_scale)
            main_video = cv2.resize(frame, (main_width, main_height))
            
            # 应用圆角
            if params['corner_radius'] > 0:
                main_video = self.apply_corner_radius(main_video, params['corner_radius'])
            
            # 应用边框
            if params['border_width'] > 0:
                main_video = self.apply_border(main_video, params['border_width'], params['border_color'])
            
            # 合并主视频和背景
            x_offset = (width - main_width) // 2
            y_offset = (height - main_height) // 2
            
            opacity = (100 - params['opacity']) / 100
            if opacity < 1:
                roi = background[y_offset:y_offset+main_height, x_offset:x_offset+main_width]
                main_video = cv2.addWeighted(roi, 1-opacity, main_video, opacity, 0)
            
            background[y_offset:y_offset+main_height, x_offset:x_offset+main_width] = main_video
            
            return background
            
        except Exception as e:
            print(f"处理帧时出错: {str(e)}")
            return frame  # 如果处理出错，返回原始帧

    def process_video(self, input_path, output_path, params):
        """处理整个视频，包括视频和音频"""
        temp_video_path = None
        input_clip = None
        processed_clip = None
        
        # 更新音频参数
        self.set_audio_volume(params['volume'])
        self.set_audio_mute(params['mute'])
        
        try:
            print("开始处理视频...")
            print(f"当前音量设置: {self.audio_params['volume']}, 静音: {self.audio_params['mute']}")
            
            # 打开输入视频
            input_cap = cv2.VideoCapture(input_path)
            if not input_cap.isOpened():
                raise Exception("无法打开输入视频文件")

            # 获取视频信息
            fps = input_cap.get(cv2.CAP_PROP_FPS)
            width = int(input_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(input_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

            print(f"视频信息: {width}x{height} @ {fps}fps")

            # 创建临时视频文件
            temp_video_path = os.path.join(self.temp_dir, 'temp_video.mp4')
            fourcc = cv2.VideoWriter_fourcc(*'avc1')
            out = cv2.VideoWriter(temp_video_path, fourcc, fps, (width, height))

            # 处理视频帧
            frame_count = 0
            while True:
                ret, frame = input_cap.read()
                if not ret:
                    break
                processed_frame = self.process_frame(frame, params)
                out.write(processed_frame)
                frame_count += 1

            print(f"处理了 {frame_count} 帧视频")

            # 释放视频写入器
            out.release()
            input_cap.release()

            print("开始处理音频...")

            # 使用moviepy处理音频
            try:
                # 加载原始视频
                print("正在加载原始视频...")
                input_clip = VideoFileClip(input_path)
                
                if input_clip.audio is None:
                    print("原始视频没有音频轨道")
                else:
                    print("检测到音频轨道")
                    
                # 加载处理后的视频
                print("正在加载处理后的视频...")
                processed_clip = VideoFileClip(temp_video_path)

                # 处理音频
                if input_clip.audio is not None and not self.audio_params['mute']:
                    volume = self.audio_params['volume']  # 使用存储的音量值
                    print(f"正在设置音量: {volume}")
                    
                    # 设置音频
                    audio = input_clip.audio
                    
                    # 调整音量
                    if volume != 1.0:
                        audio = audio.volumex(volume)
                    
                    # 将调整后的音频添加到视频
                    processed_clip = processed_clip.set_audio(audio)
                else:
                    processed_clip = processed_clip.set_audio(None)

                # 写入最终视频文件
                print("正在写入最终视频文件...")
                processed_clip.write_videofile(
                    output_path,
                    codec='libx264',
                    audio_codec='aac',
                    temp_audiofile=os.path.join(self.temp_dir, "temp-audio.m4a"),
                    remove_temp=True,
                    verbose=True
                )
                
                print("视频处理完成")
                return True

            except Exception as e:
                print(f"处理音频时出错: {str(e)}")
                # 如果音频处理失败，保存无音频的视频
                if os.path.exists(temp_video_path):
                    import shutil
                    print("音频处理失败，保存无音频视频")
                    shutil.copy2(temp_video_path, output_path)
                return True

        except Exception as e:
            print(f"处理视频时出错: {str(e)}")
            return False

        finally:
            # 清理资源
            if input_clip is not None:
                input_clip.close()
            if processed_clip is not None:
                processed_clip.close()
                
            # 删除临时文件
            if temp_video_path and os.path.exists(temp_video_path):
                try:
                    os.remove(temp_video_path)
                except:
                    pass

    def save_video(self, input_path, output_path, params):
        """保存处理后的视频（包括音频）"""
        return self.process_video(input_path, output_path, params)

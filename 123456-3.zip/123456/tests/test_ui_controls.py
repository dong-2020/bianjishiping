import unittest
from PyQt6.QtWidgets import QApplication, QVBoxLayout, QWidget
from PyQt6.QtCore import Qt
import sys
from src.ui_controls import VideoControls

class TestVideoControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # 创建QApplication实例
        cls.app = QApplication(sys.argv)
        
    def setUp(self):
        self.controls = VideoControls()
        self.test_widget = QWidget()
        self.test_layout = QVBoxLayout()
        self.test_widget.setLayout(self.test_layout)
        
    def test_create_control_panel(self):
        # 测试控制面板创建
        panel = self.controls.create_control_panel()
        self.assertIsNotNone(panel)
        
    def test_reset_controls(self):
        # 创建控制面板以初始化所有控件
        self.controls.create_control_panel()
        
        # 修改一些控件的值
        self.controls.main_scale_slider.setValue(70)
        self.controls.corner_slider.setValue(20)
        self.controls.border_slider.setValue(5)
        self.controls.opacity_slider.setValue(30)
        self.controls.volume_slider.setValue(150)
        self.controls.mute_checkbox.setChecked(True)
        
        # 重置控件
        self.controls.reset_controls()
        
        # 验证默认值
        self.assertEqual(self.controls.main_scale_slider.value(), 80)
        self.assertEqual(self.controls.corner_slider.value(), 0)
        self.assertEqual(self.controls.border_slider.value(), 0)
        self.assertEqual(self.controls.opacity_slider.value(), 0)
        self.assertEqual(self.controls.volume_slider.value(), 100)
        self.assertFalse(self.controls.mute_checkbox.isChecked())
        
    def test_update_border_slider(self):
        # 创建控制面板以初始化所有控件
        self.controls.create_control_panel()
        
        # 测试更新边框滑块
        self.controls.update_border_slider(30)
        self.assertEqual(self.controls.border_slider.maximum(), 30)
        
        # 测试当前值大于新的最大值时的情况
        self.controls.border_slider.setValue(20)
        self.controls.update_border_slider(10)
        self.assertEqual(self.controls.border_slider.value(), 10)
        
    def test_main_controls(self):
        # 创建控制面板
        self.controls.create_control_panel()
        
        # 测试主视频缩放滑块
        self.assertEqual(self.controls.main_scale_slider.minimum(), 60)
        self.assertEqual(self.controls.main_scale_slider.maximum(), 90)
        self.assertEqual(self.controls.main_scale_slider.value(), 80)
        
        # 测试圆角滑块
        self.assertEqual(self.controls.corner_slider.minimum(), 0)
        self.assertEqual(self.controls.corner_slider.maximum(), 50)
        self.assertEqual(self.controls.corner_slider.value(), 0)
        
        # 测试音量控制
        self.assertEqual(self.controls.volume_slider.minimum(), 0)
        self.assertEqual(self.controls.volume_slider.maximum(), 200)
        self.assertEqual(self.controls.volume_slider.value(), 100)
        
    def test_background_controls(self):
        # 创建控制面板
        self.controls.create_control_panel()
        
        # 测试模糊滑块
        self.assertEqual(self.controls.blur_slider.minimum(), 1)
        self.assertEqual(self.controls.blur_slider.maximum(), 99)
        self.assertEqual(self.controls.blur_slider.value(), 45)
        
        # 测试背景缩放滑块
        self.assertEqual(self.controls.bg_scale_slider.minimum(), 110)
        self.assertEqual(self.controls.bg_scale_slider.maximum(), 150)
        self.assertEqual(self.controls.bg_scale_slider.value(), 120)
        
        # 测试亮度滑块
        self.assertEqual(self.controls.brightness_slider.minimum(), -50)
        self.assertEqual(self.controls.brightness_slider.maximum(), 50)
        self.assertEqual(self.controls.brightness_slider.value(), 0)
        
        # 测试饱和度滑块
        self.assertEqual(self.controls.saturation_slider.minimum(), 0)
        self.assertEqual(self.controls.saturation_slider.maximum(), 200)
        self.assertEqual(self.controls.saturation_slider.value(), 100)
        
if __name__ == '__main__':
    unittest.main()

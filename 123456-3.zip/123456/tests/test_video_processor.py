import unittest
import numpy as np
import cv2
from src.video_processor import VideoProcessor

class TestVideoProcessor(unittest.TestCase):
    def setUp(self):
        self.processor = VideoProcessor()
        # 创建测试用的图像
        self.test_image = np.zeros((100, 100, 3), dtype=np.uint8)
        self.test_image[:] = 128  # 灰色图像
        
    def test_apply_corner_radius(self):
        # 测试圆角效果
        result = self.processor.apply_corner_radius(self.test_image.copy(), 20)
        self.assertEqual(result.shape, self.test_image.shape)
        # 检查角落是否变透明
        self.assertEqual(result[0, 0, 0], 0)
        
        # 测试边界值
        result_zero = self.processor.apply_corner_radius(self.test_image.copy(), 0)
        self.assertTrue(np.array_equal(result_zero, self.test_image))
        
        # 测试负值
        result_negative = self.processor.apply_corner_radius(self.test_image.copy(), -10)
        self.assertTrue(np.array_equal(result_negative, self.test_image))
        
        # 测试超大圆角
        result_large = self.processor.apply_corner_radius(self.test_image.copy(), 200)
        self.assertEqual(result_large.shape, self.test_image.shape)
        
    def test_apply_border(self):
        # 测试边框效果
        border_color = (255, 0, 0)  # 红色边框
        result = self.processor.apply_border(self.test_image.copy(), 5, border_color)
        self.assertEqual(result.shape, self.test_image.shape)
        # 检查边框颜色
        self.assertTrue(np.array_equal(result[0, 0], border_color))
        
        # 测试边界值
        result_zero = self.processor.apply_border(self.test_image.copy(), 0, border_color)
        self.assertTrue(np.array_equal(result_zero, self.test_image))
        
        # 测试负值
        result_negative = self.processor.apply_border(self.test_image.copy(), -5, border_color)
        self.assertTrue(np.array_equal(result_negative, self.test_image))
        
        # 测试不同颜色
        black_border = (0, 0, 0)
        result_black = self.processor.apply_border(self.test_image.copy(), 5, black_border)
        self.assertTrue(np.array_equal(result_black[0, 0], black_border))
        
    def test_apply_background_effect(self):
        # 测试背景效果
        # 测试镜像效果
        result = self.processor.apply_background_effect(self.test_image.copy(), "镜像")
        self.assertEqual(result.shape, self.test_image.shape)
        # 验证镜像效果是否正确
        self.assertTrue(np.array_equal(result[:, 0], self.test_image[:, -1]))
        
        # 测试左右渐变
        result = self.processor.apply_background_effect(self.test_image.copy(), "左右渐变")
        self.assertEqual(result.shape, self.test_image.shape)
        # 验证左边比右边暗
        self.assertTrue(np.mean(result[:, 0]) < np.mean(result[:, -1]))
        
        # 测试上下渐变
        result = self.processor.apply_background_effect(self.test_image.copy(), "上下渐变")
        self.assertEqual(result.shape, self.test_image.shape)
        # 验证上边比下边暗
        self.assertTrue(np.mean(result[0]) < np.mean(result[-1]))
        
        # 测试无效效果
        result_invalid = self.processor.apply_background_effect(self.test_image.copy(), "无效效果")
        self.assertTrue(np.array_equal(result_invalid, self.test_image))
        
    def test_adjust_hue(self):
        # 测试色调调整
        result = self.processor.adjust_hue(self.test_image.copy(), 90)
        self.assertEqual(result.shape, self.test_image.shape)
        
        # 测试边界值
        result_zero = self.processor.adjust_hue(self.test_image.copy(), 0)
        self.assertTrue(np.array_equal(result_zero, self.test_image))
        
        # 测试360度旋转
        result_360 = self.processor.adjust_hue(self.test_image.copy(), 360)
        self.assertTrue(np.allclose(result_360, self.test_image, atol=1))
        
    def test_adjust_brightness_contrast(self):
        # 测试亮度调整
        result = self.processor.adjust_brightness_contrast(self.test_image.copy(), 50)
        self.assertEqual(result.shape, self.test_image.shape)
        self.assertTrue(np.mean(result) > np.mean(self.test_image))
        
        # 测试负值亮度
        result_negative = self.processor.adjust_brightness_contrast(self.test_image.copy(), -50)
        self.assertTrue(np.mean(result_negative) < np.mean(self.test_image))
        
        # 测试零值
        result_zero = self.processor.adjust_brightness_contrast(self.test_image.copy(), 0)
        self.assertTrue(np.array_equal(result_zero, self.test_image))
        
    def test_adjust_saturation(self):
        # 测试饱和度调整
        result = self.processor.adjust_saturation(self.test_image.copy(), 150)
        self.assertEqual(result.shape, self.test_image.shape)
        
        # 测试零饱和度（黑白图像）
        result_zero = self.processor.adjust_saturation(self.test_image.copy(), 0)
        hsv_zero = cv2.cvtColor(result_zero, cv2.COLOR_BGR2HSV)
        self.assertTrue(np.all(hsv_zero[:, :, 1] == 0))
        
        # 测试正常饱和度
        result_normal = self.processor.adjust_saturation(self.test_image.copy(), 100)
        self.assertTrue(np.array_equal(result_normal, self.test_image))
        
    def test_process_frame(self):
        # 测试完整的帧处理
        params = {
            'main_scale': 80,
            'corner_radius': 20,
            'border_width': 5,
            'border_color': (255, 0, 0),
            'opacity': 0,
            'blur': 21,
            'bg_scale': 120,
            'brightness': 0,
            'saturation': 100,
            'hue': 0,
            'effect': "无"
        }
        
        result = self.processor.process_frame(self.test_image.copy(), params)
        self.assertEqual(result.shape, self.test_image.shape)
        
        # 测试极端参数
        extreme_params = {
            'main_scale': 60,
            'corner_radius': 50,
            'border_width': 20,
            'border_color': (0, 0, 0),
            'opacity': 50,
            'blur': 99,
            'bg_scale': 150,
            'brightness': 50,
            'saturation': 200,
            'hue': 180,
            'effect': "镜像"
        }
        
        result_extreme = self.processor.process_frame(self.test_image.copy(), extreme_params)
        self.assertEqual(result_extreme.shape, self.test_image.shape)
        
if __name__ == '__main__':
    unittest.main()
